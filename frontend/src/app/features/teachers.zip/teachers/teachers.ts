import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatCardModule } from '@angular/material/card';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatChipsModule } from '@angular/material/chips';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatNativeDateModule } from '@angular/material/core';
import { MatMenuModule } from '@angular/material/menu';
import { MatTooltipModule } from '@angular/material/tooltip';

interface Teacher {
  name: string;
  photo: string;
  slots: string[];
}

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [
    CommonModule,
    MatCardModule,
    MatButtonModule,
    MatIconModule,
    MatChipsModule,
    MatFormFieldModule,
    MatInputModule,
    MatDatepickerModule,
    MatNativeDateModule,
    MatMenuModule,
    MatTooltipModule
  ],
  templateUrl: './teachers.html',
  styleUrls: ['./teachers.css']
})
export class Teachers {
  selectedDate: Date = new Date('2026-01-05');
  selectedTime: string | null = null;

  timeOptions: string[] = [
    '06:00 am', '07:00 am', '08:00 am', '09:00 am',
    '05:00 pm', '06:00 pm', '07:00 pm', '08:00 pm'
  ];

  teachers: Teacher[] = [
    {
      name: 'Anita Rathod',
      photo: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=300&h=300&fit=crop',
      slots: ['07:00am', '07:00am', '07:00am', '07:00am', '07:00am', '07:00am']
    },
    {
      name: 'Sakshi Pable',
      photo: 'https://images.unsplash.com/photo-1594744803329-e58b31de8bf5?w=300&h=300&fit=crop',
      slots: ['07:00am', '07:00am', '07:00am', '07:00am', '07:00am', '07:00am']
    },
    {
      name: 'Ansh Agarwal',
      photo: 'https://images.unsplash.com/photo-1489980557514-251d61e3eeb6?w=300&h=300&fit=crop',
      slots: ['07:00am', '07:00am', '07:00am', '07:00am', '07:00am', '07:00am']
    },
    {
      name: 'Anita Rathod',
      photo: 'https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?w=300&h=300&fit=crop',
      slots: ['07:00am', '07:00am', '07:00am', '07:00am', '07:00am', '07:00am']
    },
    {
      name: 'Sakshi Pable',
      photo: 'https://images.unsplash.com/photo-1531123897727-8f129e1688ce?w=300&h=300&fit=crop',
      slots: ['07:00am', '07:00am', '07:00am', '07:00am', '07:00am', '07:00am']
    },
    {
      name: 'Ansh Agarwal',
      photo: 'https://images.unsplash.com/photo-1522075469751-3a6694fb2f61?w=300&h=300&fit=crop',
      slots: ['07:00am', '07:00am', '07:00am', '07:00am', '07:00am', '07:00am']
    }
  ];

  bookSeat(teacher: Teacher): void {
    console.log('Booking requested for', teacher.name);
  }

  requestSlot(): void {
    console.log('Slot request submitted');
  }
}